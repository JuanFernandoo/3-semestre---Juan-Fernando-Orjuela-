
package poliAbsHer;

public class Rectangulo extends FiguraAbstracta {
    
   // Inicialización de variables para el encapsulamiento de datos
    private double base;
    private double altura;
    
    // Constructor para inicializar base y altura
    public Rectangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    // Encapsulamiento de datos por medio de getter y setter
    
    //Get: Obtiene
    public double getBase() {
        return base;
    }
    //Set establecen valor
    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    
     // Implementamos el metodo calcular area
    @Override
    public double calcularArea() {
        return base*altura;
    }
}
