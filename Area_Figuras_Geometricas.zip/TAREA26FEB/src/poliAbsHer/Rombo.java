
package poliAbsHer;

public class Rombo extends FiguraAbstracta{

        // Inicialización de variables para el encapsulamiento de datos
        private double diagonalMenor;
        private double diagonalMayor;

        
     // Constructor para inicializar las diagonales
     public Rombo(double diagonalMenor, double diagonalMayor) {
        this.diagonalMenor = diagonalMenor;
        this.diagonalMayor = diagonalMayor;
    }
     
    // Encapsulamiento de datos por medio de getter y setter
    public double getDiagonalMenor() {
        return diagonalMenor;
    }

    public void setDiagonalMenor(double diagonalMenor) {
        this.diagonalMenor = diagonalMenor;
    }

    public double getDiagonalMayor() {
        return diagonalMayor;
    }

    public void setDiagonalMayor(double diagonalMayor) {
        this.diagonalMayor = diagonalMayor;
    }

    @Override
    public double calcularArea() {
        return (diagonalMayor*diagonalMenor)/2;
    }
        
}
