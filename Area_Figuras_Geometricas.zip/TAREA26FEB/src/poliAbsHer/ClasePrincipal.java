
package poliAbsHer;

import javax.swing.JOptionPane;

public class ClasePrincipal {
    public static void main(String[] args) {
    int opcion =0;// Declaración de variables opcion
    double area = 0.0; // Variable para calcular el area de las figuras

        do {//Incio bucle DO-WHILE
            opcion= Integer.parseInt(JOptionPane.showInputDialog("MENU DE OPCIONES\n"
                    + "CALCULA EL AREA DE FIGURAS GEOMETRICAS\n"
                    + "\n1.Circulo"
                    + "\n2.Triangulo"
                    + "\n3.Rectangulo"
                    + "\n4.Cuadrado"
                    + "\n5.Rombo"
                    + "\n6.Trapecio"
                    + "\n7.Paralelogramo"
                    + "\n8.Pentagono Regular "
                    + "\n9.Salir"));
       // Interfaz de opciones para mostrar al usuario las opciones   
       
       switch (opcion){// Inicio condicional switch 
           
           case 1: //Area Circulo 
              double radioCirculo= Double.parseDouble(JOptionPane.showInputDialog("Ingrese el area del circulo:"));
              
              Circulo circulo= new Circulo(radioCirculo);
              area= circulo.calcularArea(); //Calculamos area de la figura
              
              JOptionPane.showMessageDialog(null, String.format("El area del circulo es: %.3f", area)); //Metofo formar para especificar cantidad de decimales por medio de:
              break;                                                                                                               //%.nf donde n es la cantidad de decimales
           
           case 2: // Area triangulo
              double baseTriangulo= Double.parseDouble(JOptionPane.showInputDialog("Ingrese la base del rectangulo:"));
              double alturaTriangulo= Double.parseDouble(JOptionPane.showInputDialog("Ingrese la altura del rectangulo:"));
              
              Triangulo triangulo= new Triangulo(baseTriangulo, alturaTriangulo);
              area= triangulo.calcularArea(); //Calculamos area de la figura
              
              JOptionPane.showMessageDialog(null, String.format("El area del triangulo es: %.3f", area));
              break;
              
           case 3: // Area rectangulo
              double baseRectangulo= Double.parseDouble(JOptionPane.showInputDialog("Ingrese la base del rectangulo:"));
              double alturaRectangulo= Double.parseDouble(JOptionPane.showInputDialog("Ingrese la altura del rectangulo:"));
              
              Rectangulo rectangulo= new Rectangulo(baseRectangulo, alturaRectangulo);
              area= rectangulo.calcularArea();//Calculamos area de la figura
              
              JOptionPane.showMessageDialog(null, String.format("El area del rectangulo es: %.3f", area));             
              break;
              
           case 4: // Area cuadrado
               double ladoCuadrado= Double.parseDouble(JOptionPane.showInputDialog("Ingrese el lado del cuadrado"));
               
               Cuadrado cuadrado= new Cuadrado(ladoCuadrado);
               area= cuadrado.calcularArea(); //Calculamos area de la figura
               
              JOptionPane.showMessageDialog(null, String.format("El area del cuadrado es: %.3f", area));
               break;
               
           case 5: // Area rombo
               double diagonalMayor= Double.parseDouble(JOptionPane.showInputDialog("Ingrese la diagonal Mayor del rombo: "));
               double diagonalMenor= Double.parseDouble(JOptionPane.showInputDialog("Ingrese la diagonal menor del rombo: "));
               
               Rombo rombo= new Rombo(diagonalMenor, diagonalMayor);
               area= rombo.calcularArea(); //Calculamos area de la figura
               
               JOptionPane.showMessageDialog(null, String.format("El area del rombo es: %.3f", area));             
               break;
               
           case 6: //Area trapecio
               double base1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la base 1 del trapecio: "));
               double base2= Double.parseDouble(JOptionPane.showInputDialog("Ingrese la base 2 del trapecio: "));
               double altura= Double.parseDouble(JOptionPane.showInputDialog("Ingrese la altura del trapecio: "));

               
               Trapecio trapecio= new Trapecio(base1, base2, altura);
               area= trapecio.calcularArea(); //Calculamos area de la figura
               
               JOptionPane.showMessageDialog(null, String.format("El area del trapecio es: %.3f", area));             
               break;
               
           case 7:// Area paralelogramo
               double baseParalelo= Double.parseDouble(JOptionPane.showInputDialog("Ingrese la base del paralelogramo:"));
               double alturaParalelo= Double.parseDouble(JOptionPane.showInputDialog("Ingrese la altura del paralelogramo:"));
              
               Paralelogramo paralelogramo= new Paralelogramo(baseParalelo, alturaParalelo);
               area= paralelogramo.calcularArea();//Calculamos area de la figura
              
               JOptionPane.showMessageDialog(null, String.format("El area del paralelograma es: %.3f", area));             
               break;
               
           case 8: // Area pentagono regular
               double perimetroPentagono= Double.parseDouble(JOptionPane.showInputDialog("Ingrese el perimetro del pentagono regular:"));
               double apotemaPentagono= Double.parseDouble(JOptionPane.showInputDialog("Ingrese el apotema del pentagono regular:"));
              
               pentagonoRegular peRegular= new pentagonoRegular(perimetroPentagono, apotemaPentagono);
               area= peRegular.calcularArea();//Calculamos area de la figura
              
               JOptionPane.showMessageDialog(null, String.format("El area del pentagono regular es: %.3f", area));             
               break;
               
           case 9: 
               opcion= 9;
               break;
               
           default:
               JOptionPane.showMessageDialog(null, "OPCION INCORRECTA");
       }
            
        } while (opcion!=9); // El bucle se repite hasta que se ingrese la opcion 5 
    }
    
}
