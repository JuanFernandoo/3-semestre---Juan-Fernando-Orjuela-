
package poliAbsHer;

public class pentagonoRegular extends FiguraAbstracta {
    
    // Inicialización de variables para el encapsulamiento de datos
    private double perimetro;
    private double apotema;

    // Constructor para inicializar las bases y la altura
    public pentagonoRegular(double perimetro, double apotema) {
        this.perimetro = perimetro;
        this.apotema = apotema;
    }

    // Encapsulamiento de datos por medio de getter y setter
    public double getPerimetro() {
        return perimetro;
    }

    public void setPerimetro(double perimetro) {
        this.perimetro = perimetro;
    }

    public double getApotema() {
        return apotema;
    }

    public void setApotema(double apotema) {
        this.apotema = apotema;
    }

    @Override
    public double calcularArea() {
        return (perimetro * apotema) / 2;
    }
    
    
}
