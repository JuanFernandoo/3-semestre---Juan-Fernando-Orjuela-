
package poliAbsHer;

public class Paralelogramo extends FiguraAbstracta{
    
    // Inicialización de variables para el encapsulamiento de datos
    private double base;
    private double altura;

    // Constructor para inicializar las bases y la altura
    public Paralelogramo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    // Encapsulamiento de datos por medio de getter y setter
    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public double calcularArea() {
        return base*altura;
    }
    
}
