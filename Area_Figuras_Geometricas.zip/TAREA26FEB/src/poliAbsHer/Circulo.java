
package poliAbsHer;

public class Circulo extends FiguraAbstracta {
    // Inicialización de variables para el encapsulamiento de datos
    private double radio;
    
    //Contructor para inicializar radio
    public Circulo(double radio) {
        this.radio = radio;
    }
    // Encapsulamiento de datos por medio de getter y setter
    
    //Get: Obtiene
    public double getRadio() {
        return radio;
    }
    //Set establecen valor
    public void setRadio(double radio) {
        this.radio = radio;
    }

    @Override
    public double calcularArea() {
        return Math.PI *radio*radio;
    }
    
    
}
