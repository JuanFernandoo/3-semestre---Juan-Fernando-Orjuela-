
package poliAbsHer;

public abstract class FiguraAbstracta {
    
    //Cualquier clase que se herede de FiguraAbstracta debe implementar este metodo
    public abstract double calcularArea ();
}
