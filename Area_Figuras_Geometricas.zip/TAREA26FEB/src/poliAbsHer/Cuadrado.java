
package poliAbsHer;

public class Cuadrado extends Rectangulo {
    
     // Inicialización de variables para el encapsulamiento de datos
     private double lado;

    public Cuadrado(double lado) {
        super(lado, lado);
        this.lado = lado;
    }
    
    // Encapsulamiento de datos por medio de getter y setter
    
    //Get: Obtiene
    public double getLado() {
        return lado;
    }
    //Set establecen valor
    public void setLado(double lado) {
        this.lado = lado;
    }

    @Override
    public double calcularArea() {
        return lado*lado;
    }
    
}
