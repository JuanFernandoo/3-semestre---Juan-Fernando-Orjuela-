package tienda;

import java.util.Collections;
import java.util.LinkedList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class tiendaUcompensar extends javax.swing.JFrame {
    
    LinkedList<tiendaFinal> T= new LinkedList <> ();

    public tiendaUcompensar() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelTitulo = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        labelPrecio = new javax.swing.JLabel();
        labelProducto1 = new javax.swing.JLabel();
        labelPrecio1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textFieldProducto = new javax.swing.JTextField();
        textFieldCantidad = new javax.swing.JTextField();
        textFieldPrecio = new javax.swing.JTextField();
        buttonGuardar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        buttonEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jMarket = new javax.swing.JTable();
        Ascender = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        labelPrecio.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        labelPrecio.setText("CANTIDAD");

        labelProducto1.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        labelProducto1.setText("PRODUCTO");

        labelPrecio1.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        labelPrecio1.setText("PRECIO");

        textFieldProducto.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        textFieldProducto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        textFieldProducto.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));

        textFieldCantidad.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        textFieldCantidad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        textFieldCantidad.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));

        textFieldPrecio.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        textFieldPrecio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        textFieldPrecio.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));

        buttonGuardar.setBackground(new java.awt.Color(0, 153, 255));
        buttonGuardar.setFont(new java.awt.Font("Dubai", 1, 14)); // NOI18N
        buttonGuardar.setForeground(new java.awt.Color(255, 255, 255));
        buttonGuardar.setText("GUARDAR");
        buttonGuardar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        buttonGuardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonGuardar.setDefaultCapable(false);
        buttonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonGuardarActionPerformed(evt);
            }
        });

        btnBuscar.setBackground(new java.awt.Color(51, 204, 0));
        btnBuscar.setFont(new java.awt.Font("Dubai", 1, 14)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscar.setText("BUSCAR");
        btnBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBuscar.setDefaultCapable(false);
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        buttonEliminar.setBackground(new java.awt.Color(255, 0, 0));
        buttonEliminar.setFont(new java.awt.Font("Dubai", 1, 14)); // NOI18N
        buttonEliminar.setForeground(new java.awt.Color(255, 255, 255));
        buttonEliminar.setText("ELIMINAR");
        buttonEliminar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        buttonEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonEliminar.setDefaultCapable(false);
        buttonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonEliminarActionPerformed(evt);
            }
        });

        jMarket.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jMarket.setFont(new java.awt.Font("Dubai", 1, 14)); // NOI18N
        jMarket.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CANTIDAD", "PRECIO", "PRODUCTO"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jMarket.setToolTipText("");
        jMarket.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jScrollPane1.setViewportView(jMarket);

        Ascender.setBackground(new java.awt.Color(255, 102, 0));
        Ascender.setFont(new java.awt.Font("Dubai", 1, 14)); // NOI18N
        Ascender.setForeground(new java.awt.Color(255, 255, 255));
        Ascender.setText("ORDENAR");
        Ascender.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Ascender.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Ascender.setDefaultCapable(false);
        Ascender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AscenderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelPrecio)
                            .addComponent(labelPrecio1)
                            .addComponent(labelProducto1)))
                    .addComponent(jLabel4))
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(buttonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(97, 97, 97)
                        .addComponent(buttonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textFieldProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(labelTitulo)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Ascender, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(180, 180, 180))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(textFieldProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(labelProducto1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel1))
                                .addGap(62, 62, 62)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(labelPrecio, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textFieldCantidad, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(labelPrecio1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(textFieldPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel6)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(labelTitulo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(Ascender, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(buttonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(49, 49, 49))
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonEliminarActionPerformed
    String producto = JOptionPane.showInputDialog("Por favor ingrese el nombre del producto a eliminar");

    for (tiendaFinal tdn : T){
        if (tdn.getNombre().equalsIgnoreCase(producto)){
            T.remove(tdn);
            actualizarTabla();
            return;
            }
        }
    }//GEN-LAST:event_buttonEliminarActionPerformed

    private void buttonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonGuardarActionPerformed
        
    String nombreProducto = textFieldProducto.getText();
    int cantidad = Integer.parseInt(textFieldCantidad.getText());
    int precio = Integer.parseInt(textFieldPrecio.getText());
    
    tiendaFinal uMarket = new tiendaFinal(nombreProducto, cantidad, precio);
    T.add(uMarket);

    DefaultTableModel model = (DefaultTableModel) jMarket.getModel();
    model.addRow(new Object [] {textFieldCantidad.getText(), textFieldPrecio.getText(), textFieldProducto.getText()});

    textFieldCantidad.setText("");
    textFieldPrecio.setText("");
    textFieldProducto.setText("");

    }//GEN-LAST:event_buttonGuardarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
     String producto = JOptionPane.showInputDialog("Por favor ingrese el nombre del producto a buscar");
     Collections.sort(T, (t1, t2) -> t1.getNombre().compareTo(t2.getNombre()));

  tiendaFinal tiend = buscarPorNombre(producto);
  if (tiend != null) {
    JOptionPane.showMessageDialog(this, "producto: " + " " + tiend);
  } else {
    JOptionPane.showMessageDialog(this, "Producto NO encontrado");
  }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void AscenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AscenderActionPerformed
    Collections.sort(T, (t1, t2) -> Integer.compare(t1.getPrecio(), t2.getPrecio()));
    actualizarTabla();
    }//GEN-LAST:event_AscenderActionPerformed

    public void ordenarPorPrecio(){
    Collections.sort(T, (t1, t2) -> Integer.compare(t1.getPrecio(), t2.getPrecio()));
    actualizarTabla();
    }
    
    public tiendaFinal buscarPorNombre(String producto){
    int left = 0;
    int right = T.size() - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;
        tiendaFinal tiend = T.get(mid);
        int comparar = tiend.getNombre().compareTo(producto);
        
        if (comparar == 0) {
            return tiend;
        } else if (comparar < 0) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return null;
    }


    private void actualizarTabla() {
    DefaultTableModel model= (DefaultTableModel) jMarket.getModel();
    model.setRowCount(0);   
        for (tiendaFinal td:T){
            model.addRow(new Object[]{td.getCantidad(), td.getPrecio(), td.getNombre()});
        }      
    }
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tiendaUcompensar().setVisible(true);
            }
        });
    }   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ascender;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton buttonEliminar;
    private javax.swing.JButton buttonGuardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTable jMarket;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelPrecio;
    private javax.swing.JLabel labelPrecio1;
    private javax.swing.JLabel labelProducto1;
    private javax.swing.JLabel labelTitulo;
    private javax.swing.JTextField textFieldCantidad;
    private javax.swing.JTextField textFieldPrecio;
    private javax.swing.JTextField textFieldProducto;
    // End of variables declaration//GEN-END:variables
}